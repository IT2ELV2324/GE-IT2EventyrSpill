import math
from os import system
from Classes.index import Player
from Enemy.index import Enemy


def player_combat(player,enemy):
    if (player.check_if_within_reach_player(enemy.xpos, enemy.ypos))
        combat = True
    while combat:
        Enemy.hp -= Player.attack



