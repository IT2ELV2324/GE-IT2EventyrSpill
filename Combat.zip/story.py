print (f'Du gikk en tur i skogen og kom over en hule.', end = " ") 
print (f'Ut av hulen kom det en musikk fylt av sorg og håp.', end = " " )
print (f'Musikken trekker deg inn. Gjennom hulen kommer du til et mystisk sted.', end = " ")
print (f'Alt du klarer å tenke på er å slå den onde Slemsing.', end = " ") 
print (f'En raspete dame stemme snakker til deg: "Hva er din historie?"')

